<?php

/**
 * @license GPL-2.0+
 */

return [

	'AwesomeService' => function () {
		return new \stdClass();
	}

];
