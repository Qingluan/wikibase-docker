<?php

namespace Wikibase\Client\Usage;

use Exception;

/**
 * @license GPL-2.0+
 * @author Daniel Kinzler
 */
class UsageTrackerException extends Exception {

}
