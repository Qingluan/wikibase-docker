<?php
include __DIR__ . '/config/WikibaseClient.example.php';
