# Not implemented in current release

Current release of Wikidata Query Service does not yet have support for the following features:

1. Redirects - implemented only as Q1 owl:sameAs Q2 triple, no further processing.
2. No access control & restrictions for Blazegraph instance implemented.
3. Units are not supported for geospatial search.
